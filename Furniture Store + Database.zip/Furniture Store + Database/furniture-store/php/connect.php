<?php
    $connection = mysqli_connect("localhost", "root", "YES");
    if (!$connection) die("<ERROR: Cannot connect to database>");
    $database = mysqli_select_db($connection, "furniture_store");
    if (!$database) die("<ERROR:Cannot select database>");

    
?>
